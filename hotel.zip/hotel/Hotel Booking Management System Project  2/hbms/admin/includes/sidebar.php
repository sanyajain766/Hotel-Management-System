    <div class="sidebar-menu">
                    <header class="logo1">
                      <span style="color:#000; font-size:26px; font-weight:bold">HBMS</span>
                        <a href="#" class="sidebar-icon"><span class="fa fa-bars"></span> </a> 
                    </header>
                        <div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
                                    <ul id="menu" >
                                        <li><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Home</span></a></li>
                                         <li id="menu-academico" ><a href="#"><i class="fa fa-table"></i> <span> Room Category</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                                           <ul id="menu-academico-sub" >
                                           <li id="menu-academico-avaliacoes" ><a href="add-category.php">Add Category</a></li>
                                            <li id="menu-academico-avaliacoes" ><a href="manage-category.php">Manage Catgeory</a></li>
                                           
                                          </ul>
                                        </li>
                                          <li id="menu-academico" ><a href="#"><i class="lnr lnr-layers"></i> <span>Facility</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                                         <ul id="menu-academico-sub" >
                                            <li id="menu-academico-avaliacoes" ><a href="add-facility.php">Add Facility</a></li>
                                            <li id="menu-academico-boletim" ><a href="manage-facility.php">Manage Facility</a></li>

                                          </ul>
                                     </li>
                                      <li id="menu-academico" ><a href="#"><i class="lnr lnr-pencil"></i> <span>New Room</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                                         <ul id="menu-academico-sub" >
                                            <li id="menu-academico-avaliacoes" ><a href="add-room.php">Add Room</a></li>
                                            <li id="menu-academico-boletim" ><a href="manage-room.php">Manage Room</a></li>

                                          </ul>
                                     </li>
                                     <li id="menu-academico" ><a href="#"><i class="fa fa-file-text-o"></i> <span>Page</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                                         <ul id="menu-academico-sub" >
                                            <li id="menu-academico-avaliacoes" ><a href="aboutus.php">About Us</a></li>
                                            <li id="menu-academico-boletim" ><a href="contactus.php">Contact Us</a></li>

                                          </ul>
                                     </li>
                                     <li id="menu-academico" ><a href="#"><i class="lnr lnr-book"></i> <span>Booking</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                                         <ul id="menu-academico-sub" >
                                            <li id="menu-academico-avaliacoes" ><a href="all-booking.php">All Booking</a></li>
                                            <li id="menu-academico-boletim" ><a href="new-booking.php">New Booking</a></li>
                                            <li id="menu-academico-boletim" ><a href="approved-booking.php">Approved Booking</a></li>
                                            <li id="menu-academico-boletim" ><a href="cancelled-booking.php">Cancelled Booking</a></li>

                                          </ul>
                                     </li>
                                    <li><a href="reg-users.php"><i class="lnr lnr-users"></i> <span>Reg Users</span></a></li>
                                    <li id="menu-academico" ><a href="#"><i class="lnr lnr-book"></i> <span>Enquiry</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                                         <ul id="menu-academico-sub" >
                                            <li id="menu-academico-avaliacoes" ><a href="read-enquiry.php">Read Enquiry</a></li>
                                            <li id="menu-academico-boletim" ><a href="unread-enquiry.php">Unread Enquiry</a></li>
                                           
                                          </ul>
                                     </li>
                                      <li id="menu-academico" ><a href="#"><i class="fa fa-file-text-o"></i> <span>Search</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                                         <ul id="menu-academico-sub" >
                                            <li id="menu-academico-avaliacoes" ><a href="search-enquiry.php">Search Enquiry</a></li>
                                            <li id="menu-academico-boletim" ><a href="search-booking.php">Search Booking</a></li>
                                           
                                          </ul>
                                     </li>
                                    
                                  
                                    <li id="menu-academico" ><a href="#"><i class="lnr lnr-layers"></i> <span>Reports</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                                         <ul id="menu-academico-sub" >
                                            <li id="menu-academico-avaliacoes" ><a href="enquiry-betdates-reports.php">Enquiry B/W Reports</a></li>
                                            <li id="menu-academico-boletim" ><a href="booking-betdates-reports.php">Booking B/W Reports</a></li>

                                          </ul>
                                     </li>
                                    
                                  </ul>
                                </div>
                              </div>