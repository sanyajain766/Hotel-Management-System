<div>
         
            <div class="footer">
                    <div class="clearfix"> </div>
                        <p style="font-family: cursive;">© 2020 Hotel Booking Management System </p>
            </div>
        </div>