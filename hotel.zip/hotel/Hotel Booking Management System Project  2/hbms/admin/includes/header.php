<div class="header-section">
            <!-- top_bg -->
                        <div class="top_bg">
                            
                                <div class="header_top">
                                    <div class="top_right">
                                        <ul>
                                            <li><a href="profile.php">Profile</a></li>|
                                            <li><a href="change-password.php">Change Password</a></li>|
                                            <li><a href="logout.php">Logout</a></li>
                                        </ul>
                                    </div>
                                   
                                        <div class="clearfix"> </div>
                                </div>
                            
                        </div>
                    <div class="clearfix"></div>
                <!-- /top_bg -->
                </div>
                <div class="header_bg">
                        
                            <div class="header">
                                <div class="head-t">
                                    <div class="logo">
                                        <a href="dashboard.php" style="font-size: 20px;color: red">Hotel Booking Management System </a>
                                    </div>
                                        <!-- start header_right -->
                                    
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    
                </div>