<div class="footer-section">
						<div class="container">
							<div class="footer-top">
								<p>Hotel Booking Management Sytem @ 2020 </p>
							</div>
						
				</div>
			</div>